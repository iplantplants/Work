java -cp Structorizer.app/Contents/Java/Structorizer.jar lu.fisch.structorizer.arranger.Arranger
